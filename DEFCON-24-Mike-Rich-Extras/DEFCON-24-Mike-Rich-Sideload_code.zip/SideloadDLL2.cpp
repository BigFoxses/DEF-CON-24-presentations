// SideloadDLL2.cpp : Defines the exported functions for the DLL application.
//

#include "stdafx.h"

#include "sideload.h"

#include <string>
#include <fstream>

using namespace std;

// Encode a sideload BBC
// Since string refs to and from VBA pretty much suck, needs to also save a data file based on the fileout name
// This data must be provided when the sideload is decoded
int WINAPI DLLencode_adv(char* filename_in, char* filename_out, int blckthresh = 150, int masksize = 5, int wigglesize = 3, int n_val = 255, int k_val = 140) {
	// VBA strings are basically null-terminated char, convert to strings to make them safe and useful!
	string filenamein(filename_in);
	string filenameout(filename_out);
	
	string datafilename = filenamein + ".dat";
	ofstream datafile(datafilename);
	datafile << "Start\n";
	datafile.flush();

	try {
		Sideload_class sideload;
		sideload.setBlackThreshold(blckthresh);
		sideload.setMaskValues(masksize, wigglesize);
		sideload.setReedSolomon(n_val, k_val);
		string md5;
		datafile << "Filename: " << filenamein << "\n";
		datafile << "Encoded filename root: " << filenameout << "\n";
		datafile << "Values set:\n";
		datafile << blckthresh << ", " << masksize << ", " << wigglesize << ", " << n_val << ", " << k_val << "\n";
		datafile.flush();
		long filelength = sideload.encodeSLD(filenamein, filenameout, &md5);
		datafile << "Encoded\n";
		datafile.flush();

		// Now we need to save the data to a file for decode purposes
		//string datafilename = filenamein + ".dat";
		//ofstream datafile(datafilename);
		datafile << "Encoded data length: " << filelength << "\n";
		datafile << "File md5: " << md5 << "\n";
		datafile.close();

		return 1;
	}
	catch (exception e) {
		datafile << "Fail: " << e.what() << "\n";
		datafile.flush();
		datafile.close();
		return 0;
	}
}

int WINAPI DLLencode(char* filename_in, char* filename_out) {
	// Oh VBA.  Doesn't handle default arguments correctly.  So, this is a helper function to do it right
	// If you want to set the details, you need to call DLLencode_adv directly from VBA
	// prototype VBA DLL declaration:
	// Declare Function DLLencode Lib "C:\location\SideloadDLL2.dll" (ByVal filein As String, ByVal fileout As String) As Integer

	return DLLencode_adv(filename_in, filename_out);
}

// decode BBC files
// filenames in is a ';' delimited list of filenames, given in the order they are to be processed
// This is a hack since passing arrays of strings is totally unweildy from VBA
// md5 and filesize must come from the ".dat" file left behind when the encoding is done
int WINAPI DLLdecode_adv(char* filenames_in, char* filename_out, char* md5, long filesize, int blckthresh = 150, int masksize = 5, int wigglesize = 3, int n_val = 255, int k_val = 140) {
	string filenamein(filenames_in);	
	string filenameout(filename_out);
	string datafilename = filenameout + ".dat";
	ofstream datafile(datafilename);
	datafile << "Start\n";
	datafile.flush();

	string md5sum(md5);
	
	BBCFileArr_t filesToDecode;
	size_t start = 0;
	size_t posn = 0;
	while (posn != std::string::npos) {
		posn = filenamein.find(';', start);
		filesToDecode.push_back(filenamein.substr(start, (posn - start)));
		start = posn + 1;
	}
	
	try {
		Sideload_class sideload;
		sideload.setBlackThreshold(blckthresh);
		sideload.setMaskValues(masksize, wigglesize);
		sideload.setReedSolomon(n_val, k_val);
		string md5;
		datafile << "Filenames: \n";
		for (int i = 0; i < len(filesToDecode); i++) {
			datafile << filesToDecode[i] << "\n";
		}
		datafile << "Decoded filename: " << filenameout << "\n";
		datafile << "Values set:\n";
		datafile << blckthresh << ", " << masksize << ", " << wigglesize << ", " << n_val << ", " << k_val << "\n";
		datafile << "Filesize: " << filesize << "\n";
		
		datafile.flush();
		bool result = sideload.decodeSLD(&filesToDecode, filenameout, md5sum, filesize);

		if (result) {
			datafile << "Decoded\n";
			datafile.flush();
			return 1;
		}
		else {
			datafile << "Decode failed\n";
			datafile.flush();
			datafile.close();
			return 0;
		}

	}
	catch (exception e) {
		datafile << "Fail: " << e.what() << "\n";
		datafile.flush();
		datafile.close();
		return 0;
	}
}

int WINAPI DLLdecode(char* filenames_in, char* filename_out, char* md5, long filesize) {
	// Here to allow default value calls, just like above
	// prototype VBA DLL declaration:
	// Declare Function DLLdecode Lib "C:\location\SideloadDLL2.dll" (ByVal filesin As String, ByVal fileout As String, ByVal md5 As String, filesize As Long) As Integer
	return DLLdecode_adv(filenames_in, filename_out, md5, filesize);
}