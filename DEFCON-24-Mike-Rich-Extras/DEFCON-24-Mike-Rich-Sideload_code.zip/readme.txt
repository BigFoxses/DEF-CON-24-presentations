This POC code has not been organized for ease of compiling yet.  Sorry about that.

You will need to add the files here to a Visual Studio DLL project, 
as well as fix some settings for dangerous c functions.
The underlying open source libraries are rife with low-level memory allocation and copy functions.
Visual Studio doesn't like that so it will require you to set the _CRT_SECURE_NO_WARNINGS flag in your
c++ preprocessor flags.
