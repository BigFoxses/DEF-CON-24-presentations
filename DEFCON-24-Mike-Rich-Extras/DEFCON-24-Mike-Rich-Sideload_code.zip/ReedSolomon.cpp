//
//  ReedSolomon.cpp
//  RSExp
//
//  Created by MICHAEL RICH on 9/27/15.
//  Copyright (c) 2015 Mike Rich. All rights reserved.
//

#include "ReedSolomon.h"
#include "galois_cpp.h"

// #include <iomanip>
// DEBUG
#include <iostream>
#include <stdexcept>
#include <stdlib.h>

using namespace std;

//string printByteArr(byteArr_t* arr) {
//    stringstream result;
//    result << "[";
//    for (int i = 0; i < arr->size(); i++) {
//        result << hex << setw(2) << setfill('0') << ((short int)arr->at(i) & 0xff) << ", ";
//    }
//    
//    result << "]";
//    return result.str();
//}

ReedSolomon::ReedSolomon(int n_init, int k_init) {
    // n, k, and s as defined at: http://www.cs.cmu.edu/~guyb/realworld/reedsolomon/reed_solomon_codes.html
    // For s = 8, at least, the n is the MAX data length.  The encoder will encode a single byte with n-k parity
    // As long as you subtract n-k from each codeword, you'll get the initial message back
    
    
    n = n_init;
    k = k_init;
    s = 8;
    w = s;
    
    if (n > 255) {
        throw runtime_error("Codeword too big, limited to 255");
    }
    
    if ((k == 0) || (k > n)) {
        throw runtime_error("Data size is not set right.  Must be > 0 and < 2^n");
    }
    
    galois_create_log_tables(w);
}

ReedSolomon::~ReedSolomon() {
    // Placeholder
}

//void ReedSolomon::copyStringToByteArr(string::iterator dataStart, string::iterator dataStop, byteArr_t* dataout) {
//    // This is necessary due to the unsigned char issue writing these data back and forth
//    string::iterator index = dataStart;
//    dataout->clear();
//    int byteArrIndex = 0;
//    
//    while (index != dataStop) {
//        dataout->push_back((unsigned char)(*index));
//        index++;
//        byteArrIndex++;
//    }
//    
//}

//void ReedSolomon::appendByteArrToString(byteArr_t* datain, string* dataout) {
//    // See above
//    for (int i = 0; i < len_ptr(datain); i++) {
//        dataout->push_back((unsigned char)(*datain)[i]);
//    }
//}
//
//void ReedSolomon::appendByteArrToString(byteArr_t* datain, string* dataout, int numbytes) {
//    // See above
//    for (int i = 0; i < numbytes; i++) {
//        dataout->push_back((unsigned char)(*datain)[i]);
//    }
//}

int ReedSolomon::reduceByteArr(byteArr_t* data) {
    int length = len_ptr(data);
    int sum = 0;
    for (int i = 0; i < len_ptr(data); i++) {
        sum += (*data)[i];
    }
    return sum;
}


int ReedSolomon::encode(string* data, string* encoded_data) {
    // Returns the padding added to the data.  Not necessary for s = 8, but probable for 16
    int nsym = n - k;
    encoded_data->clear();
    
    byteArr_t msg_in;
    byteArr_t msg_out;
    string::iterator data_index = data->begin();
    string::iterator data_end = data->end();
    while (data_index != data_end) {
        // Set data grab size
        int data_grab_length = k;
        if ((data_end - data_index) < k) {
            data_grab_length = (data_end - data_index);
        }
        // set up the byte vector
        msg_in.assign(data_index, (data_index+data_grab_length));
        //copyStringToByteArr(data_index, (data_index+data_grab_length), &msg_in);
        
        // increment index
        data_index += data_grab_length;
        
        // encode it
        rs_encode_msg(&msg_in, nsym, &msg_out);
        
        // insert into outgoing encoded_data
        encoded_data->insert(encoded_data->end(), msg_out.begin(), msg_out.end());
        //appendByteArrToString(&msg_out, encoded_data);
    }
    return 0;
}

// Decode the data
int ReedSolomon::decode(string* encodedData, string* decodedData) {
    // Returns -1 on error, with reason in decodeData
    try {
        decodedData->clear();
        int nsym = n-k;
        byteArr_t syndromes;
        byteArr_t err_loc;
        byteArr_t err_pos;
        byteArr_t msg;
        
        string::iterator data_index = encodedData->begin();
        string::iterator data_end = encodedData->end();
        
        while (data_index != data_end) {// Set data grab size
            int data_grab_length = n;
            if ((data_end - data_index) < n) {
                data_grab_length = (data_end - data_index);
            }
            // set up the byte vector
            msg.assign(data_index, (data_index+data_grab_length));
            //copyStringToByteArr(data_index, (data_index+data_grab_length), &msg);
            
            // increment index
            data_index += data_grab_length;
            
            // First calc syndromes
            rs_calc_syndromes(&msg, nsym, &syndromes);
            int syndromeSum = reduceByteArr(&syndromes);
            
            if (syndromeSum != 0) {
                // Don't need to do this is syndromes are zero..  No errors
                // Calc error polynomial
                rs_gen_error_poly(&syndromes, &err_loc);
                
                // Calc error positions
                rs_find_errors(&err_loc, len(msg), &err_pos);
                
                // Fix the message
                rs_correct_errata(&msg, &syndromes, &err_pos);
            }
            
            // msg is data + parity bytes, so need to just pull off the data
            decodedData->insert(decodedData->end(), msg.begin(), msg.begin() + (len(msg) - nsym));
            //appendByteArrToString(&msg, decodedData, (len(msg) - nsym));
        }
    } catch (runtime_error& e) {
        decodedData->assign(e.what());
        return -1;
    }
    
    return 0;
}

//int ReedSolomon::gf_test_mul(int x, int y) {
//    return gf_mul(x, y);
//}
//int ReedSolomon::gf_test_div(int x, int y) {
//    return gf_div(x, y);
//}

int ReedSolomon::align(byteArr_t* p, byteArr_t* q) {
    int len_p = len_ptr(p);
    int len_q = len_ptr(q);
    
    if (len_p == len_q) return len_p;  // Nothing to be done
    if (len_p < len_q) {
        // Shift p values to the right to align polynomial coefficients
        p->insert(p->begin(), len_q-len_p, 0);
    } else {
        // shift q values to the right to align polynomials
        q->insert(q->begin(), len_p - len_q, 0);
    }
    
	return (len_p > len_q) ? len_p :len_q;
    //return max(len_p, len_q);
}



void ReedSolomon::gf_poly_mul(byteArr_t* p, byteArr_t* q, byteArr_t* result) {
    // Clear the answer
    result->clear();
    // fill with zeros
    result->insert(result->begin(), p->size() + q->size() - 1, 0x00);
    
    // Begin iteration
    for (int j = 0; j < q->size(); j++) {
        for (int i=0; i < p->size(); i++) {
            int x = p->at(i);
            int y = q->at(j);
            result->at(i+j) = result->at(i+j) ^ gf_mul(x, y);
        }
    }
    
}

byte_t ReedSolomon::gf_poly_eval(byteArr_t* p, int x) {
    byte_t y = p->at(0);
    for (int i = 1; i < p->size(); i++) {
        int pati = (*p)[i];
        y = gf_mul(y, x) ^ fixint(pati);
    }
    return fixint(y);
}

void ReedSolomon::gf_poly_div(byteArr_t* dividend, byteArr_t* divisor, byteArr_t* quotient, byteArr_t* remainder) {
    // Placeholder
    //int imax = dividend->size() -
    
}

int ReedSolomon::gf_exp(int i) {
    return fixint(galois_get_ilog_table(w)[fixint(i)]);
}

int ReedSolomon::gf_log(int i) {
    return fixint(galois_get_log_table(w)[fixint(i)]);
}

void ReedSolomon::gf_poly_scale(byteArr_t* p, int x, byteArr_t* result) {
	result->clear();
	result->insert(result->begin(), len_ptr(p), 0);
	for (int i = 0; i < len_ptr(p); i++) {
		(*result)[i] = gf_mul((*p)[i], x);
	}
	return;
	
/*	unsigned char* p_char = p->data();
    int numbytes = len_ptr(p);
    
    // init result and allocate appropriate space
    result->clear();
    result->insert(result->begin(), numbytes, 0);
    unsigned char* result_char = result->data();
    
    if (w == 8) {
        //galois_w08_region_multiply(p_char, x, numbytes, result_char, 0);
		galois_w08_region_multiply(p_char, x, numbytes, result->data(), 0);
    }
//    else if (w == 16) {
//        galois_w16_region_multiply(p_char, x, numbytes, result_char, 0);
//    }
    */
}

void ReedSolomon::gf_poly_add(byteArr_t* p, byteArr_t* q, byteArr_t* result) {
	// First align the polys
	int len_p = len_ptr(p);
	int len_q = len_ptr(q);
	int numbytes = (len_p > len_q) ? len_p : len_q;
	result->clear();
	result->insert(result->begin(), numbytes, 0);
	int len_r = len_ptr(result);
	for (int i = 0; i < len_p; i++) {
		(*result)[i + len_r - len_p] = (*p)[i];
	}
	for (int i = 0; i < len_q; i++) {
		(*result)[i + len_r - len_q] ^= (*q)[i];
	}
	return;

	
	// First align the polys
/*    int numbytes = align(p, q);
    
    // Init the result
    result->clear();
    result->insert(result->begin(), numbytes, 0);
    
    galois_region_xor(p->data(), q->data(), result->data(), numbytes);
	*/
}

int ReedSolomon::fixint(int i) {
    // negative indexes and results are killing me, and resulting in all sorts of "unsigned char" statements
    // everywhere.
    // Instead, a simple function to fix negative numbers for various sizes of w
    switch (w) {
        case 8:
            return (i & 0xff);
            break;
        case 16:
            return (i & 0xffff);
            break;
        default:
            return (i);
            break;
    }
}

void ReedSolomon::rs_generator_poly(int nsym, byteArr_t* genpoly) {
	//DEBUG
	//cout << "rs_generator_poly\n";

    // Clear the answer
    genpoly->clear();
    // initialize
    genpoly->push_back(1);
    
    for (int i = 0; i < nsym; i++) {
        byteArr_t q, result;
        q.push_back(1);
        q.push_back((unsigned char)gf_exp(i));
        gf_poly_mul(genpoly, &q, &result);
        *genpoly = result;
    }
    
}


void ReedSolomon::rs_encode_msg(byteArr_t* msg_in, int nsym, byteArr_t* msg_out){
    // nsym = number of error correction symbols (need 2*t remember)
    // msg_in needs to be < 2^s length!  Not checking!
    
    byteArr_t gen;
    rs_generator_poly(nsym, &gen);
    // Init msg_out with msg_in and then pad to length of gen - 1 bytes (which is actually just nsym)
    *msg_out = *msg_in;
    // Pad with zeros
    msg_out->insert(msg_out->begin()+msg_in->size(), nsym, 0x00);
    
    for (int i = 0; i < msg_in->size(); i++) {
        unsigned char coef = (unsigned char)msg_out->at(i);
        
        if (coef != 0) {
            for (int j = 1; j < gen.size(); j++) {
                msg_out->at(i+j) ^= gf_mul(gen[j], coef);
            }
        }
    }
    
    // Recopy the original message back into msg_out
    for (int i = 0; i < msg_in->size(); i++) {
        msg_out->at(i) = msg_in->at(i);
    }
    
}

void ReedSolomon::rs_calc_syndromes(byteArr_t* msg, int nsym, byteArr_t* syndromes) {
	//DEBUG
	//cout << "Calc syndromes\n";
    // init syndromes
    syndromes->clear();
    
    for (int i = 0; i < nsym; i++){
        syndromes->push_back(gf_poly_eval(msg, (unsigned char)gf_exp(i)));
    }
}

void ReedSolomon::rs_find_errata_locator(byteArr_t* err_pos, byteArr_t* e_loc) {
	//DEBUG
	//cout << "rs_find_errata_locator\n";
    e_loc->clear();
    e_loc->push_back(1);
    
    for (int i = 0; i < len_ptr(err_pos); i++) {
        byteArr_t temp_e_loc, temp_poly1, temp_poly2, result;
        temp_poly1.push_back(1);
        temp_poly2.push_back((unsigned char)gf_exp((unsigned char)err_pos->at(i)));
        temp_poly2.push_back(0);
        gf_poly_add(&temp_poly1, &temp_poly2, &result);
        gf_poly_mul(e_loc, &result, &temp_e_loc);
        *e_loc = temp_e_loc;
    }
    
}

void ReedSolomon::rs_find_error_evaluator(byteArr_t* synd, byteArr_t* err_loc, int nsym, byteArr_t* remainder) {
	//DEBUG
	//cout << "rs_find_error_evaluator\n";

    byteArr_t temp_remainder;
    gf_poly_mul(synd, err_loc, &temp_remainder);
    remainder->assign((temp_remainder.begin()+len(temp_remainder)-(nsym+1)), temp_remainder.end());
}

void ReedSolomon::rs_gen_error_poly(byteArr_t* syndromes, byteArr_t* err_loc) {
	//DEBUG
	//cout << "rs_gen_error_poly\n";

	// init err_loc
    err_loc->clear();
    byteArr_t old_loc;
    err_loc->push_back(1);
    old_loc.push_back(1);
    
    for (int i = 0; i < syndromes->size(); i++) {
		////cout << "syndrome loop, i = " << i << "\n";
        old_loc.push_back(0);
        unsigned char delta = syndromes->at(i);
        
        for (int j = 1; j < len_ptr(err_loc); j++) {
            delta ^= gf_mul(err_loc->at(len_ptr(err_loc) - 1 - j), syndromes->at(i-j));
        }
		
		
        if (delta) {
            if (len(old_loc) > len_ptr(err_loc)) {
                // poly scale is galois_wXX_region_multiply(..)
                byteArr_t new_loc;
                gf_poly_scale(&old_loc, delta, &new_loc);
                gf_poly_scale(err_loc, gf_div(1, delta), &old_loc);
                //*err_loc = new_loc;
				err_loc->assign(new_loc.begin(), new_loc.end());
                
            }
            byteArr_t temp_err_loc;
            byteArr_t temp_old_loc;
            gf_poly_scale(&old_loc, delta, &temp_old_loc);
            gf_poly_add(err_loc, &temp_old_loc, &temp_err_loc);
            //*err_loc = temp_err_loc;
			err_loc->assign(temp_err_loc.begin(), temp_err_loc.end());
			////cout << "end of if delta\n";
        }
		////cout << "end of syndrome loop, i = " << i << "\n";
    }
    // Need to drop the leading zeroes from err_loc
    byteArr_t temp_err_loc;
    bool foundFirstNonZero = false;
    for (int i = 0; i < len_ptr(err_loc); i++) {
        char value = err_loc->at(i);
        if (foundFirstNonZero) {
            temp_err_loc.push_back(value);
        } else {
            if (value != 0) {
                foundFirstNonZero = true;
                temp_err_loc.push_back(value);
            }
        }
    }
    
	err_loc->assign(temp_err_loc.begin(), temp_err_loc.end());
    
    
}

void ReedSolomon::rs_find_errors(byteArr_t* err_loc, int nmess, byteArr_t* err_pos) {
	//DEBUG
	//cout << "rs_find_errors\n";

    int errs = len_ptr(err_loc) - 1;
    err_pos->clear();
    
    for (int i = 0; i < nmess; i++) {
        // This is only set up for w = 8 currently..
        int gfexp = (unsigned char)gf_exp(255-i);
        byte_t result = gf_poly_eval(err_loc, gfexp);
        if (result == 0) err_pos->push_back(nmess - 1 - i);
    }
    if (len_ptr(err_pos) == 0){
        // Couldn't find any errors
        throw runtime_error("Too many errors to correct");
    }
}

void ReedSolomon::rs_correct_errata(byteArr_t* msg, byteArr_t* syndromes, byteArr_t* err_pos) {
	//DEBUG
	//cout << "correct errata\n";
    // This function will correct the mangled msg in msg, storing the result in msg
    // The final msg will be the data + parity bytes, which need to be stripped off as nsym
    // Could do here or in the public decode function, for now following the tutorial
    // Only valid for w = 8
    byteArr_t coef_pos;
    for (int i = 0; i < len_ptr(err_pos); i++) {
        coef_pos.push_back(len_ptr(msg) - 1 - (*err_pos)[i]);
    }
    
    byteArr_t loc;
    rs_find_errata_locator(&coef_pos, &loc);
    
        // Slice and reverse order the syndrome
    byteArr_t synd;
    for (int i = len_ptr(err_pos); i >= 0; i--) {
        synd.push_back((*syndromes)[i]);
    }
    
    byteArr_t eval;
    rs_find_error_evaluator(&synd, &loc, (len_ptr(err_pos)-1), &eval);
    
    byteArr_t locprime;
    // Calculate locprime by eliminating even coefficients from loc
    for (int i = (len(loc) & 1); i < len(loc); i = i + 2) {
        locprime.push_back(loc[i]);
    }
    
    // During debug, locprime gets mangled some how (first byte changes)
    // This stopped it..  But i don't know why it was happening in the first place
    byteArr_t locprime_math = locprime;
    
    for (int i = 0; i < len_ptr(err_pos); i++) {
        //byteArr_t locprime_math = locprime;
        int x_index = (*err_pos)[i] + 256 - len_ptr(msg);
        int x = gf_exp(x_index);
        int y = gf_poly_eval(&eval, x);
        int z = gf_poly_eval(&locprime_math, gf_mul(x, x));
        byte_t magnitude = gf_div(y, gf_mul(x, z));
        
        // The signed/unsigned problems here require the line below.
        int errpos_i = fixint((*err_pos)[i]);
        (*msg)[errpos_i] ^= magnitude;
    }
    // done? - BAM!  Yes!
}
