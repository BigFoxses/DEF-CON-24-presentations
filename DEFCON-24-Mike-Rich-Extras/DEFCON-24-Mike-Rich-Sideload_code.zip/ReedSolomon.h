//
//  ReedSolomon.h
//  RSExp
//
//  Created by MICHAEL RICH on 9/27/15.
//  Copyright (c) 2015 Mike Rich. All rights reserved.
//

/* This is my attempt to instantiate Reed Solomon error encoding as described at:
 https://en.wikiversity.org/wiki/Reed%E2%80%93Solomon_codes_for_coders#Reed.E2.80.93Solomon_codes
 To make it easier to do, I will declare private functions names the same as in the tutorial, but
 they will simply be passthroughs into the fast galois math functions provided at :
 http://web.eecs.utk.edu/~plank/plank/papers/CS-07-593/
 
 Eventually, I may eliminate the passthroughs
 */

/* Function mapping from the tutorial to the library:
 gf_mult_noLUT(a,b, prim) -> galois_single_multiply(a,b,w)
    galois library performs the modular reduction without the prim, w should be set to symbol bit size
 
 gf_mul(x,y) -> galois_logtable_multiply(int x, int y, int w)
 gf_div(x,y) -> galois_logtable_divide(int x, int y, int w)
    These probably need to be preceeded by galois_create_log_tables(int w)
    w = 8
 
 gf_poly_scale(p,x) -> galois_wXX_region_multiply(char *p, int x, numbytes, char* result, add = 0?)
    Very odd effect: at some level of input value, results come back negative signed..  Not sure if it effects the math or not?
    The "root" of the byte is correct (0x88 vs ffx88)
    This is correct, but due to the byteArr_t still need to write the functions as an "API" to the native galois code
 
 gf_poly_add(p,q) -> galois_region_xor(char* p, char* q, char* result, numbytes)
    This is correct, but due to the byteArr_t still need to write the functions as an "API" to the native galois code
 
 gf_poly_mul -> NO EQUIVALENT?
 gf_poly_eval -> NO EQUIVALENT?
    But the functions in the algorithm are above
 
 gf_exp -> galois_get_ilog_table
 
 */

#ifndef __RSExp__ReedSolomon__
#define __RSExp__ReedSolomon__

#include <stdio.h>

#include <string>
#include <vector>
// #include <sstream>

using namespace std;

#define gf_mul(x,y) fixint(galois_logtable_multiply(fixint(x),fixint(y),w))
#define gf_div(x,y) fixint(galois_logtable_divide(fixint(x),fixint(y),w))

// These only work on standard containers, specifically designed to use on byteArr_t below
#define len_ptr(x) x->size()
#define len(x) x.size()

typedef unsigned char byte_t;
typedef vector<byte_t> byteArr_t;

//string printByteArr(byteArr_t* arr);

class ReedSolomon {
  // Instance Variables (TBD)
    int n;
    int k;
    int s;
    int w;
    
    // string genpoly;

public:
    ReedSolomon(int n_init, int k_init);
    ~ReedSolomon();
    
    // Encode an arbitrary amount of data, will work in proper chunks and return a completed string
    // Returns the padlength?
    int encode(string* data, string* encoded_data);
    
    // Decode the data
    int decode(string* encodedData, string* decodedData);
    
private:
    int align(byteArr_t* p, byteArr_t* q);
    void gf_poly_mul(byteArr_t* p, byteArr_t* q, byteArr_t* result);
    byte_t gf_poly_eval(byteArr_t* p, int x);
    void gf_poly_div(byteArr_t* dividend, byteArr_t* divisor, byteArr_t* quotient, byteArr_t* remainder);
    int gf_exp(int i);
    int gf_log(int i);
    //int gf_test_mul(int x, int y);
    //int gf_test_div(int x, int y);
    void gf_poly_scale(byteArr_t* p, int x, byteArr_t* result);
    void gf_poly_add(byteArr_t* p, byteArr_t* q, byteArr_t* result);
    //void copyStringToByteArr(string::iterator dataStart, string::iterator dataStop, byteArr_t* dataout);
    //void appendByteArrToString(byteArr_t* datain, string* dataout);
    //void appendByteArrToString(byteArr_t* datain, string* dataout, int numbytes);
    int reduceByteArr(byteArr_t* data);
    int fixint(int i);
    
    void rs_generator_poly(int nsym, byteArr_t* genpoly);
    void rs_encode_msg(byteArr_t* msg_in, int nsym, byteArr_t* msg_out);
    void rs_calc_syndromes(byteArr_t* msg, int nsym, byteArr_t* syndromes);
    void rs_find_errata_locator(byteArr_t* err_pos, byteArr_t* e_loc);
    void rs_find_error_evaluator(byteArr_t* synd, byteArr_t* err_loc, int nsym, byteArr_t* remainder);
    void rs_gen_error_poly(byteArr_t* syndromes, byteArr_t* err_loc);
    void rs_find_errors(byteArr_t* err_loc, int nmess, byteArr_t* err_pos);
    void rs_correct_errata(byteArr_t* msg, byteArr_t* syndromes, byteArr_t* err_pos);
    
};

#endif /* defined(__RSExp__ReedSolomon__) */
